using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class colision : MonoBehaviour
{
    void OnCollisionEnter(Collision collision)
    {
        if (collision.transform.tag == "enemigo")
        {
            Destroy(collision.transform.gameObject);
        }
    }
}

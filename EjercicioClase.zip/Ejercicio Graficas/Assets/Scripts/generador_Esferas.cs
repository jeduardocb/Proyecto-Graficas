using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class generador_Esferas : MonoBehaviour
{
    public GameObject prefa_esfera;
    public int cantidad;
    public int rangoX;
    public int rangoZ;

    private int contador;
    // Start is called before the first frame update
    void Start()
    {
        contador = 0;
        StartCoroutine(prefabSpawn());
        //Instantiate(prefa_esfera, new Vector3(0,1,0),Quaternion.identity);
    }

    // Update is called once per frame
    void Update()
    {
       /* contador++;
        if (contador % 120 == 0)
        {
            Instantiate(prefa_esfera, new Vector3(0, 1, 0), Quaternion.identity);
        }*/
    }

    IEnumerator prefabSpawn()
    {
        for(int i= 0; i < cantidad; i++)
        {
            float posX = Random.Range(-rangoX / 2, rangoX / 2);
            float posZ = Random.Range(-rangoZ / 2, rangoZ / 2);
            Instantiate(prefa_esfera, new Vector3(posX, 2, posZ), Quaternion.identity);
            yield return new WaitForSeconds(2);
        }

    }
       
}
